package persona;

import java.util.ArrayList;
import java.util.List;

import mesa.Mesa;

public class Comensal extends Persona{
    private List<Comensal> listaNegra;
    private List<Acompanante> acompanantes;
    
    public Comensal(String nombre,String apellidos,int edad,String parte) {
        super(nombre,apellidos,edad,parte);
    	this.listaNegra = new ArrayList<>();
        this.acompanantes = new ArrayList<>();
    }
    public void agregarListaNegra(Comensal comensal){
        listaNegra.add(comensal);
    }

    public List<Comensal> getListaNegra() {
		return listaNegra;
	}

    public void desasignarMesa() {
        this.mesa = null;
    }
    public Mesa getMesa() {
        return mesa;
    }
    public void agregarAcompanante(Acompanante acompanante) {
    	//mesa.numeroComensales++;
        acompanantes.add(acompanante);
    }
    public List<Acompanante> getAcompanantes() {
        return acompanantes;
    }
}

