package persona;

public class Acompanante extends Persona{
	public Acompanante(String nombre,String apellidos,int edad,String parte) {
		super(nombre,apellidos,edad,parte);
	}
}
