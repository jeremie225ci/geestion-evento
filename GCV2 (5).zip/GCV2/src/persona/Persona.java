package persona;

import mesa.Mesa;

public class Persona {
	 // Atributos que representan la información de una persona
	protected static int id_global= 1;
	protected Mesa mesa;
	  private int id;
	  protected String nombre;
	  protected String apellidos;
	  protected int edad;
	  protected String parte;  
	  
	  // Constructor que inicializa los atributos de la clase
	  public Persona(String nombre,String apellidos,int edad,String parte) {
		this.id = id_global;
		id_global++;
		this.nombre = nombre;
	    this.apellidos = apellidos;
	    this.edad = edad;
	    this.parte = parte;
	  }

	// Métodos para obtener y establecer los valores de los atributos
	public String getNombre() {
	    return this.nombre;
	  }

	public int getId() {
		return id;
	}
	public void asignarMesa(Mesa mesa) {
        this.mesa = mesa;
    }
	public void setId(int id) {
		this.id = id;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getParte() {
		return parte;
	}

	public void setParte(String parte) {
		this.parte = parte;
	}

	public void setNombre(String nombre) {
	    this.nombre = nombre;
	  }

	public int getEdad() {
	    return this.edad;
	  }

	public void setEdad(int edad) {
	    this.edad = edad;
	  }

	
}
