package mesa;

import java.util.ArrayList;
import java.util.List;

import persona.Acompanante;
import persona.Comensal;
import persona.Persona;

public class Mesa {
    private int numeroMesa;
    public int numeroComensales;
    private List<Persona> comensales;
    private final int capacidad = 4;  // capacidad fija de 6 comensales
    
    public Mesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
        this.numeroComensales = 0;
        this.comensales = new ArrayList<>();
    }
    
    public boolean estaLlena() {
        return comensales.size() >= capacidad;
    }
    
    public void asignarComensal(Comensal comensal) {
        this.comensales.add(comensal);
        this.numeroComensales++;
    }
    public void asignarComensal(Acompanante comensal) {
        this.comensales.add(comensal);
        this.numeroComensales++;
    }
    public void desasignarComensal(Comensal comensal) {
        this.comensales.remove(comensal);
        this.numeroComensales--;
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public int getNumeroComensales() {
        return numeroComensales;
    }

    public List<Persona> getComensales() {
        return comensales;
    }
    public boolean tieneEnListaNegra(Comensal comensal) {
        for (Persona c : comensales) {
            if (comensal.getListaNegra().contains(c)) {
                return true;
            }
        }
        return false;
    }
}
