package evento;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import persona.*;
import mesa.*;
public class Evento {
    private List<Mesa> mesas;
    private List<Comensal> comensales;
    
    public Evento() {
        this.mesas = new ArrayList<>();
        this.comensales = new ArrayList<>();
    }
    public Comensal obtenerComensal(int nombreComensal1) {
        for (Comensal comensal : comensales) {
            if (comensal.getId() == nombreComensal1) {
                return comensal;
            }
        }
        return null;
    }
    public void desasignarComensalMesa(Comensal comensal) {
        Mesa mesa = comensal.getMesa();
        if (mesa != null) {
            mesa.desasignarComensal(comensal);
            comensal.desasignarMesa();
        }
    }
    public void agregarMesa(int numeroMesa) {
        mesas.add(new Mesa(numeroMesa));
    }
    public Mesa obtenerMesa(int numeroMesa) {
        for (Mesa mesa : mesas) {
            if (mesa.getNumeroMesa() == numeroMesa) {
                return mesa;
            }
        }
        return null;
    }
    public List<Mesa> getMesas() {
        return mesas;
    }
    public void asignarComensalMesa(int nombreComensal) {
        Comensal comensal = obtenerComensal(nombreComensal);
        for (Mesa mesa : mesas) {
            boolean puedeSentarse = true;
            for (Persona acompanante : comensal.getAcompanantes()) {
                if (mesa.estaLlena()) {
                    puedeSentarse = false;
                    break;
                }
            }
            if (puedeSentarse && !mesa.tieneEnListaNegra(comensal) && !mesa.estaLlena()) {
                mesa.asignarComensal(comensal);
                comensal.asignarMesa(mesa);
                for (Acompanante acompanante : comensal.getAcompanantes()) {
                	mesa.asignarComensal(acompanante);
                	acompanante.asignarMesa(mesa);
                }
                return;
            }
        }
        // si no hay mesas disponibles se crea una nueva
        int nuevoNumeroMesa = mesas.size() + 1;
        Mesa mesa = new Mesa(nuevoNumeroMesa);
        mesas.add(mesa);
        mesa.asignarComensal(comensal);
        comensal.asignarMesa(mesa);
        for (Acompanante acompanante : comensal.getAcompanantes()) {
            if (!mesa.estaLlena()) {
                mesa.asignarComensal(acompanante);
                acompanante.asignarMesa(mesa);
            }
        }
    }
    public void agregarComensal(String nombre,String apellidos,int edad,String parte,
    		String nombrea,String apellidosa,int edada,String partea) {
        Comensal comensal = new Comensal(nombre,apellidos,edad,parte);
        if (nombrea != null) {
            Acompanante acompanante = new Acompanante(nombrea,apellidosa,edada,partea);
            comensal.agregarAcompanante(acompanante);
        }
        comensales.add(comensal);
    }
    public void mostrarInformacionComensales() {
        for (Mesa mesa : mesas) {
            System.out.println("\t **Mesa** " + mesa.getNumeroMesa() + ":");
            for (Persona comensal : mesa.getComensales()) {
                System.out.println("id:"+ comensal.getId() + " Nombre: " + comensal.getNombre());
                /*for (Persona acompanante : comensal.getAcompanantes()) {
                    System.out.println("\tAcompañante: " + acompanante.getNombre());
                }*/
            }
        }
    }
    public void agregarComensalListaNegra(int nombreComensal1, int nombreComensalListaNegra) {
        Comensal comensal = obtenerComensal(nombreComensal1);
        Comensal comensalListaNegra = obtenerComensal(nombreComensalListaNegra);
        comensal.agregarListaNegra(comensalListaNegra);
    }
    public void mostrarComensales() {
        if (comensales.isEmpty()) {
            System.out.println("No hay comensales agregados");
            return;
        }
        for (Comensal comensal : comensales) {
            System.out.println("id:"+ comensal.getId() + " Nombre: " + comensal.getNombre() + " Apellidos: "+comensal.getApellidos());
        }
    }
    public void mostrarMenu() {
    	Scanner input = new Scanner(System.in);
    	int opcion = 0;
		boolean opcion1Ejecutada = false;		
    		do {
			    System.out.println("---- Menu del evento ----");
			    System.out.println("1. Agregar comensales");
			    System.out.println("2. Asignar comensal a mesa");
			    
			    System.out.println("3. Mostrar informacion de comensales y mesas");
			    System.out.println("4. Agregar vetado.");
			    System.out.println("5. Mostrar comensales.");
			    
			    System.out.println("6. Salir");
			    System.out.print("Seleccione una opcion: ");
			    
			    try {
			    	opcion = input.nextInt();
				    switch (opcion) {
				        case 1:
				        if (!opcion1Ejecutada) {
				            System.out.println("Insertando comensales y acompañantes...");
				            agregarComensal("Juan","Perez",20,"Novia","Paco","Garcia",43,"Novia");
				            agregarComensal("Jose","Martinez",32,"Novio","Alex","Romero",23,"Novio");
				            agregarComensal("Pepe","Perez",54,"Novia","Ofelia","Tunez",43,"Novia");
				            agregarComensal("Alex","Corvera",65,"Novio","Katty","Perez",23,"Novio");
		
				            agregarComensal("Luis","Fernadez",56,"Novia","Teresa","Camacho",12,"Novia");
				            agregarComensal("Marcos","Astidillo",21,"Novio","Aroa","Uriol",12,"Novio");
				            agregarComensal("Lucia","Martinez",43,"Novia","Alex","Perez",12,"Novia");
				            agregarComensal("Alicia","Perez",52,"Novio","Tomas","Larsen",12,"Novio");
				            opcion1Ejecutada = true;
		                } else {
		                    System.out.println("La opción 1 ya ha sido ejecutada previamente. Elija otra opción.");
		                }
				            break;
				        case 2:
		                    asignarComensalMesa(1);
		                    asignarComensalMesa(3);
		                    asignarComensalMesa(5);
		                    asignarComensalMesa(7);
		                    asignarComensalMesa(9);
		                    asignarComensalMesa(11);
		                    asignarComensalMesa(13);
		                    asignarComensalMesa(15);
		                    
				            break;
				        case 3:
				        	mostrarInformacionComensales();
				            break;
		                case 4:
		                    System.out.println("Ingrese el id del comensal: ");
		                    mostrarComensales();
		                    int nombreComensal1 = input.nextInt();
		                    System.out.println("Ingrese el nombre del comensal que desea agregar a la lista negra: ");
		                    mostrarComensales();
		                    int nombreComensalListaNegra = input.nextInt();
		                    agregarComensalListaNegra(nombreComensal1, nombreComensalListaNegra);
		                    agregarComensalListaNegra(nombreComensalListaNegra, nombreComensal1);
		                    break;
		                case 5:
		                    mostrarComensales();
		                    break;
		                case 6:
				            System.out.println("Hasta luego!");
				            break;
				        default:
				            System.out.println("Opcion no valida, seleccione de nuevo");
				            break;
				    }
    		} catch (InputMismatchException e) {
    			System.out.println("Opción inválida. Debe elegir una opción del 1 al 6.\n");
    			input.nextLine(); // Vaciar el buffer del scanner
    		}
		} while (opcion != 6);
		 			
    }
}
