package main;

import evento.Evento;

public class Main {

    public static void main(String[] args) {
        Evento evento = new Evento();
        evento.mostrarMenu();
    }

}
